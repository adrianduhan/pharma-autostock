
# PharmaAutoStock

An automated reorder generation app for family pharmacies.

Upload your inventory file (CSV or Excel) and get an optimized reorder proposal instantly.
